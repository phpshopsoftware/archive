ALTER TABLE `phpshop_modules_boxberrywidget_system` ADD `fee` int(11) default 0;
ALTER TABLE `phpshop_modules_boxberrywidget_system` ADD `fee_type` enum('1','2') DEFAULT '1';