ALTER TABLE `phpshop_modules_cron_job` ADD `servers` varchar(255) default '';
ALTER TABLE `phpshop_modules_cron_system` ADD `version` varchar(64) default '1.5';