ALTER TABLE `phpshop_orders` ADD `admin` int(11) default 0;
