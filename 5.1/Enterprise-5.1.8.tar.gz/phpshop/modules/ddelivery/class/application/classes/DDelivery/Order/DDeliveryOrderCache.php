<?php
/**
 * Created by PhpStorm.
 * User: mrozk
 * Date: 8/13/14
 * Time: 5:33 PM
 */

namespace DDelivery\Order;


class DDeliveryOrderCache {

    public $sig;

    public $calculateCourier;

    public $calculateSelf;

    public $calculateSelfPoint;

}