<?php
/**
 *
* Исключения DDelivery.Sdk
*
* @package    DDelivery.Sdk
*
* @author  mrozk <mrozk2012@gmail.com>
*/
namespace DDelivery\Sdk;

class DDeliverySDKException extends \Exception{}