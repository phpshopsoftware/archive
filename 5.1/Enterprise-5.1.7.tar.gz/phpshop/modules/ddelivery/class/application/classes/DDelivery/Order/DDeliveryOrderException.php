<?php
/**
 *
* Исключения DDelivery.Order
*
* @package    DDelivery
*
* @author  mrozk
*/
namespace DDelivery\Order;

class DDeliveryOrderException extends \Exception{}