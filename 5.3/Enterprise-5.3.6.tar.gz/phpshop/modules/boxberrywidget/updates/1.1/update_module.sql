ALTER TABLE `phpshop_modules_boxberrywidget_log` ADD `status_code` varchar(64) default 'success';
ALTER TABLE `phpshop_modules_boxberrywidget_log` ADD `tracking` varchar(64) default '';