ALTER TABLE `phpshop_delivery` ADD `servers` varchar(64) default '';
ALTER TABLE `phpshop_orders` ADD `tracking` varchar(64) default '';
ALTER TABLE `phpshop_rssgraber` ADD `servers` varchar(64) default '';
ALTER TABLE `phpshop_baners` ADD `dop_cat` varchar(255) default '';
ALTER TABLE `phpshop_baners` ADD `servers` varchar(64) default '';