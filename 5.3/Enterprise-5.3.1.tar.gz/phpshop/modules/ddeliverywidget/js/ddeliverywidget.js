function ddeliverywidgetStart() {

    var products = $.parseJSON($("input:hidden.cartListJson").val());
    $('<input type="hidden" name="ddeliverySum">').insertAfter('#d');
    $('<input type="hidden" name="ddeliveryReq" class="req form-control">').insertAfter('#dop_info');
    DDeliveryWidget.init('widget', {
        products: products,
        id: $("#ddeliveryId").val(),
        width: 500,
        height: 550,
        env: DDeliveryWidget.ENV_PROD
    }, {
        change: function(data) {

            $('<input type="hidden" name="ddeliveryToken" value="' + data['client_token'] + '">').insertAfter('#d');
            $('input[name="ddeliveryReq"]').val(data['info']);
            
            $("#DosSumma").html(data['client_price']);
            $("#TotalSumma").html(Number(data['client_price']) + Number($('#OrderSumma').val()));
            $('input[name="ddeliverySum"').val(data['client_price']);

            $('input[name="city_new"]').val(data['city_name']);
            $('input[name="flat_new"]').val(data['to_flat']);
            $('input[name="house_new"]').val(data['to_house']);
            $('input[name="street_new"]').val(data['to_street']);
            
            $('#deliveryInfo').html(data['info']);
            $('#ddelivery-close').text('����������').addClass('btn-success');

            // Hook
            if ($.isFunction(window.ddeliverywidgetHook))
                ddeliverywidgetHook(data);
            /*
             setTimeout(function() {
             $("#ddeliverywidgetModal").modal("hide");
             }, 3000);*/
        }
    });

    $("#ddeliverywidgetModal").modal("toggle");
}


function ddeliverywidgetReset() {
    $('input[name="ddeliveryReq"]').remove();
}

/*
function ddeliverywidgetHook(data) {
    
    // ���������� �� ������
    if (data['city_name'] != '������') {

        // ���������� �������� �����
        var paymentStop = '3'; // �� ������ ����� �������
        if (paymentStop !== undefined)
            var payment_array = paymentStop.split(",");

        $('input[name="order_metod"]').each(function() {
            $(this).attr('disabled', false);
        });

        if ($.isArray(payment_array)) {
            $.each(payment_array, function(index, value) {
                $('input[data-option="payment' + value + '"]').attr('disabled', true);
                $('input[data-option="payment' + value + '"]').attr('checked', false);
            });
        }

        if ($("input#order_metod:checked").length == 0) {
            $('input#order_metod').each(function() {
                if (!this.disabled) {
                    this.checked = true;
                    return false;
                }
            });
        }
    }
}*/