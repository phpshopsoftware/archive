ALTER TABLE `phpshop_1c_docs` ADD `year` int(11) default 2018;
ALTER TABLE `phpshop_orders` ADD `files` text;