/*657*/
ALTER TABLE `phpshop_newsletter` ADD `recipients` text NULL;