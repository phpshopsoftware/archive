-- 
-- ���������� ������
--

ALTER TABLE `phpshop_users` CHANGE `enabled` `enabled` ENUM( '0', '1' ) DEFAULT '1' NOT NULL;
ALTER TABLE `phpshop_users` CHANGE `status` `status` ENUM( '0', '1', '2', '3' ) DEFAULT '0' NOT NULL;
ALTER TABLE `phpshop_pages` CHANGE `enabled` `enabled` ENUM( '0', '1', '2' ) DEFAULT '1' NOT NULL; 
ALTER TABLE `phpshop_categories` CHANGE `PID` `parent_to` INT( 11 ) DEFAULT '0' NOT NULL;
ALTER TABLE `phpshop_pages` CHANGE `datas` `date` VARCHAR( 64 ) CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_pages` CHANGE `enabled` `enabled` ENUM( '0', '1', '2' ) DEFAULT '1' NOT NULL 
ALTER TABLE `phpshop_baners` RENAME `phpshop_banners`;
ALTER TABLE `phpshop_news` CHANGE `datas` `date` VARCHAR( 32 ) CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_news` CHANGE `zag` `title` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_news` CHANGE `kratko` `description` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_news` CHANGE `podrob` `content` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_banners` CHANGE `datas` `date` VARCHAR( 32 ) CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_banners` CHANGE `flag` `enabled` ENUM( '0', '1' ) DEFAULT '0' NOT NULL;
ALTER TABLE `phpshop_photo_foto` RENAME `phpshop_photo` ;
ALTER TABLE `phpshop_photo_categories` CHANGE `PID` `parent_to` INT( 11 ) DEFAULT '0';
ALTER TABLE `phpshop_photo` CHANGE `PID` `category` INT( 11 ) DEFAULT '0';
ALTER TABLE `phpshop_system` CHANGE `adminmail2` `admin_mail` VARCHAR( 64 ) CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_gbook` CHANGE `datas` `date` INT( 11 ) DEFAULT NULL;
ALTER TABLE `phpshop_gbook` CHANGE `tema` `title` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci DEFAULT NULL;
ALTER TABLE `phpshop_gbook` CHANGE `otsiv` `question` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci DEFAULT NULL;
ALTER TABLE `phpshop_gbook` CHANGE `otvet` `answer` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci DEFAULT NULL;
ALTER TABLE `phpshop_gbook` CHANGE `flag` `enabled` ENUM( '0', '1' ) DEFAULT '0' NOT NULL;
ALTER TABLE `phpshop_links` CHANGE `opis` `content` TEXT CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_send_mail` CHANGE `datas` `date` VARCHAR( 32 ) CHARACTER SET cp1251 COLLATE cp1251_general_ci NOT NULL;
ALTER TABLE `phpshop_system` CHANGE `spec_num` `skin_choice` ENUM( '0', '1' ) DEFAULT '0' NOT NULL;

-- 
-- ��������
-- 
SET NAMES 'cp1251';
