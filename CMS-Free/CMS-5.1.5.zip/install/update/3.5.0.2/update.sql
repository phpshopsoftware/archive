-- 
-- ���������� ������
--

ALTER TABLE  `phpshop_users` ADD  `hash` VARCHAR( 255 ) NOT NULL;
ALTER TABLE  `phpshop_system` ADD  `addres` varchar(255) NOT NULL;



CREATE TABLE IF NOT EXISTS `phpshop_slider` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `enabled` enum('0','1') NOT NULL DEFAULT '0',
  `num` smallint(6) NOT NULL,
  `link` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251;




-- 
-- ��������
-- 
SET NAMES 'cp1251';
