(function($) {
    $.fn.datetimepicker.dates['ru'] = locale;
}(jQuery));