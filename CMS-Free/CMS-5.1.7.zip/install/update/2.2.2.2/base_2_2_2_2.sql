-- 
-- ���������� ������� `phpshop_categories`
-- 
ALTER TABLE `phpshop_categories` ADD `PID` INT( 11 ) NOT NULL ;
ALTER TABLE `phpshop_categories` ADD `content` text NOT NULL;


-- 
-- ���������� ������� `phpshop_system`
-- 
ALTER TABLE `phpshop_system` ADD `admoption` TEXT NOT NULL , ADD `rss_use` TINYINT( 1 ) NOT NULL ;


-- 
-- ��������� ������� `phpshop_photo_categories`
-- 

CREATE TABLE `phpshop_photo_categories` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `PID` int(11) default NULL,
  `link` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL default '',
  `num` tinyint(11) NOT NULL default '0',
  `content` text NOT NULL,
  `enabled` enum('0','1') NOT NULL,
  `page` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

-- 
-- ��������� ������� `phpshop_photo_foto`
-- 

CREATE TABLE `phpshop_photo_foto` (
  `id` int(11) NOT NULL auto_increment,
  `PID` int(11) default '0',
  `enabled` enum('0','1') NOT NULL,
  `name` varchar(64) NOT NULL default '',
  `num` tinyint(11) NOT NULL default '0',
  `info` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `parent` (`PID`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=98 ;

-- --------------------------------------------------------

-- 
-- ��������� ������� `phpshop_rssgraber`
-- 

CREATE TABLE `phpshop_rssgraber` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `link` text NOT NULL,
  `day_num` int(1) NOT NULL default '1',
  `news_num` mediumint(8) NOT NULL default '0',
  `enabled` enum('0','1') NOT NULL default '1',
  `start_date` int(16) unsigned NOT NULL default '0',
  `end_date` int(16) unsigned NOT NULL default '0',
  `last_load` int(16) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

-- 
-- ��������� ������� `phpshop_rssgraber_jurnal`
-- 

CREATE TABLE `phpshop_rssgraber_jurnal` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `date` int(15) unsigned NOT NULL default '0',
  `link_id` int(11) NOT NULL default '0',
  `status` enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;


-- 
-- ��������� ������� `phpshop_modules`
-- 

CREATE TABLE `phpshop_modules` (
  `path` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  PRIMARY KEY  (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;


-- 
-- ��������
-- 
SET NAMES 'cp1251';

