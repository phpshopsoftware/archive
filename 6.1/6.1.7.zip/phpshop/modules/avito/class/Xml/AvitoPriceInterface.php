<?php

interface AvitoPriceInterface
{
    public static function getXml($product);
}