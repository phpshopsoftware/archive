<?php
header('Location: ?path=catalog');