ALTER TABLE `phpshop_products` DROP COLUMN `bitrix24_product_id`;
ALTER TABLE `phpshop_categries` DROP COLUMN `bitrix24_category_id`;
ALTER TABLE `phpshop_shopusers` DROP COLUMN `bitrix24_client_id`;
ALTER TABLE `phpshop_delivery` DROP COLUMN `bitrix24_delivery_id`;