DROP TABLE IF EXISTS `phpshop_modules_alfacredit_system`;

DELETE FROM `phpshop_payment_systems` WHERE id=10045;