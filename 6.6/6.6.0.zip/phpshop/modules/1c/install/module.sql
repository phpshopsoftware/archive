
CREATE TABLE `phpshop_modules_1c_system` (
  `id` int(11) NOT NULL auto_increment,
  `version` varchar(64) default '1.0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 ;


INSERT INTO `phpshop_modules_atol_system` VALUES (1, '1.0');
