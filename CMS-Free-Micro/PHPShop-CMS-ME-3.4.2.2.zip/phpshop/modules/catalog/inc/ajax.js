function CreateRequest()
{
    var Request = false;

    if (window.XMLHttpRequest)
    {
        //Gecko-����������� ��������, Safari, Konqueror
        Request = new XMLHttpRequest();
    }
    else if (window.ActiveXObject)
    {
        //Internet explorer
        try
        {
            Request = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (CatchException)
        {
            Request = new ActiveXObject("Msxml2.XMLHTTP");
        }
    }

    if (!Request)
    {
        alert("���������� ������� XMLHttpRequest");
    }

    return Request;
}

function SendRequest(r_method, r_path, r_args, r_handler)
{

    var Request = CreateRequest();
    if (!Request)
    {
        return;
    }

    Request.onreadystatechange = function()
    {

        if (Request.readyState == 4)
        {
            r_handler(Request);
        }
    }

    if (r_method.toLowerCase() == "get" && r_args.length > 0)
        r_path += "?" + r_args;


    Request.open(r_method, r_path, true);

    if (r_method.toLowerCase() == "post")
    {
        Request.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");

        Request.send(r_args);
    }
    else
    {
        Request.send(null);
    }
}

function ReadFile(filename, container)
{

    var Handler = function(Request)
    {
        document.getElementById(container).innerHTML = Request.responseText;
    }


    SendRequest("GET",filename,"",Handler);

}

function addtovar(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzina.php','korzina')
    }
    SendRequest("GET","/handler.php","tID="+tovarID,Handler);
}

function droptovar(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzina.php','korzina')
    }
    SendRequest("GET","/handler.php","droptID="+tovarID,Handler);
}

function alldroptovar(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzina.php','korzina')
    }
    SendRequest("GET","/handler.php","alldroptovar="+tovarID,Handler);
}

function addtovarF(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzinafull.php','zakaz')
    }
    SendRequest("GET","/handler.php","tID="+tovarID,Handler);
}

function droptovarF(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzinafull.php','zakaz')
    }
    SendRequest("GET","/handler.php","droptID="+tovarID,Handler);
}

function alldroptovarF(tovarID)
{
    var Handler = function(Request)
    {
        // alert(Request.responseText);
        ReadFile('/korzinafull.php','zakaz')
    }
    SendRequest("GET","/handler.php","alldroptovar="+tovarID,Handler);
}

function spisok(num)
{
    //	alert(num);
    var itm=document.getElementById(num);
    if ( itm!= null)
    {
        //	alert(itm.style.display);
        if (itm.style.display=="")
        {
            itm.style.display="none";
        }
        else
            itm.style.display="";
    }
}
