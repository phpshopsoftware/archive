<?php


class PHPShopCatalogXML extends PHPShopElements {

    var $number_format=2;

    function PHPShopCatalogXML() {
        $this->debug=false;
        parent::PHPShopElements();
        $this->data=$GLOBALS['SysValue']['system']['catalog'];
        PHPShopObj::loadClass('string');
        include_once($GLOBALS['SysValue']['class']['connectxml']);
        $this->PHPShopConnectXML = new PHPShopConnectXML($this->data['domain'],$this->data['log'],$this->data['pas']);

        // ��������� ��������
        //if(empty($_SESSION['option']))
        $this->option();
    }


    function option() {
        $post = $this->PHPShopConnectXML->query('table_name3','select','kurs');
        $xml = $this->PHPShopConnectXML->send($post);
        $option = $this->PHPShopConnectXML->readxml($xml);

        $_SESSION['option']['kurs']=$option[0]['kurs'];

        $_SESSION['data']=$this->data;


        $post = $this->PHPShopConnectXML->query('table_name24','select','*');
        $xml = $this->PHPShopConnectXML->send($post);
        $valuta = $this->PHPShopConnectXML->readxml($xml);

        foreach($valuta as $val)
            $_SESSION['option']['valuta'][$val['id']]=$val;

        $_SESSION['option']['money']=$_SESSION['option']['valuta'][$option[0]['kurs']]['code'];
    }

    function catalog($num=false) {
        global $PHPShopModules;
        $post = $this->PHPShopConnectXML->query('table_name','select','id,name,parent_to','parent_to=0','num',$num);
        $xml = $this->PHPShopConnectXML->send($post);
        $db = $this->PHPShopConnectXML->readxml($xml);
        foreach ($db as $k=>$row) {
            $this->set('catalogName',$row['name']);
            $this->set('catalogId',$row['id']);
            $dis.=parseTemplateReturn($this->getValue('templates.catalog_forma'));
        }

        $this->set('leftMenuName','�������');
        $this->set('leftMenuContent',$dis);
        return $this->parseTemplate($this->getValue('templates.left_menu'));

    }


    function price($price,$baseinputvaluta) {
        $price=$price*$_SESSION['option']['valuta'][$baseinputvaluta]['kurs'];
        return number_format($price,$this->number_format,".","");
    }

    function product($cat,$limit=5,$order='RAND()') {
        static $highslide_load;


        $post = $this->PHPShopConnectXML->query('table_name2','select','id,name,price,pic_small,pic_big,baseinputvaluta','category='.$cat.' and enabled="1"',$order,$limit);
        $xml = $this->PHPShopConnectXML->send($post);
        $db = $this->PHPShopConnectXML->readxml($xml);

        if(empty($highslide_load)) {
            $dis='<!-- ����� ����������� ����������� �������� -->
<script type="text/javascript" src="phpshop/modules/catalog/highslide/highslide-p.js"></script>
<link rel="stylesheet" type="text/css" href="phpshop/modules/catalog/highslide/highslide.css"/>
<script type="text/javascript">
hs.registerOverlay({html: \'<div class="closebutton" onclick="return hs.close(this)" title="�������"></div>\',position: \'top right\',fade: 2});
hs.graphicsDir = \'phpshop/modules/catalog/highslide/graphics/\';
hs.wrapperClassName = \'borderless\';
</script>
<!-- ����� ����������� ����������� �������� -->
';
            $highslide_load=true;
        }

        foreach (@$db as $k=>$row) {
            $this->set('productName',$row['name']);
            $this->set('productId',$row['id']);
            $this->set('productValutaName',$_SESSION['option']['money']);
            $this->set('productLatName',PHPShopString::toLatin($row['name']));
            $this->set('productImg','http://'.$this->data['domain'].$row['pic_small']);
            $this->set('productImgBigFoto','http://'.$this->data['domain'].$row['pic_big']);
            $this->set('productPrice',$this->price($row['price'],$row['baseinputvaluta']));
            $this->set('productDescription',base64_decode($row['description']));
            $dis.=ParseTemplateReturn($GLOBALS['SysValue']['templates']['catalog']['product_forma'],true);
        }

        $this->set('leftMenuName','�������');
        $this->set('leftMenuContent',$dis);
        return $this->parseTemplate($this->getValue('templates.left_menu'));

    }


    function add($id,$num=false) {

        if(PHPShopSecurity::true_num($id)) {

            $post = $this->PHPShopConnectXML->query('table_name2','select','id,name,price,baseinputvaluta','id='.$id.' and enabled="1"');
            $xml = $this->PHPShopConnectXML->send($post);
            $db = $this->PHPShopConnectXML->readxml($xml);

            if(is_array($db)) {
                $_SESSION['CART'][$id]=$db[0];
                if(PHPShopSecurity::true_num($num)) $_SESSION['CART'][$id]['num']+=$num;
                else $_SESSION['CART'][$id]['num']++;
            }

        }
    }


    // ����� �������
    function cart() {



        $sum=0;
        $num=0;
        if(!empty($_SESSION['CART']) and is_array($_SESSION['CART']))
            foreach($_SESSION['CART'] as $key=>$val) {
                $sum+=$val['price']*$val['num'];
                $num+=$val['num'];
            }

        $dis =  "� �������: <strong>".$num."</strong> ��.<br>";
        $dis.= "�����: <strong>".$sum."</strong> ".$_SESSION['option']['money']."<br>";

        if($num>0) $dis.= '<p>
	  <form method="get" action="/cart/">
	  <input type="submit" value="�������� ����� >">
	  </form></p>';

        $this->set('leftMenuName',"�������");
        $this->set('leftMenuContent',$dis);

        return $this->parseTemplate($this->getValue('templates.right_menu'));
    }


}

// �����
if(!empty($GLOBALS['SysValue']['system']['catalog']['enabled'])) {

    $PHPShopCatalogXML = &new PHPShopCatalogXML();

    // ���������� � �������
    if(!empty($GLOBALS['SysValue']['nav']['query']['item'])) $PHPShopCatalogXML->add($GLOBALS['SysValue']['nav']['query']['item'],$GLOBALS['SysValue']['nav']['query']['nim']);

    // �������
    if($GLOBALS['SysValue']['nav']['path'] != 'cart') $GLOBALS['SysValue']['other']['rightMenu'].=$PHPShopCatalogXML->cart();

    $GLOBALS['SysValue']['other']['rightMenu'].=$PHPShopCatalogXML->product(11);
    $GLOBALS['SysValue']['other']['leftMenu'].=$PHPShopCatalogXML->product(6,3);
}
?>