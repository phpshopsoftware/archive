<?php


class PHPShopPage extends PHPShopCore {

    /**
     * �����������
     */
    function PHPShopPage() {
        parent::PHPShopCore();

        $this->data=$GLOBALS['SysValue']['system']['catalog'];
        $this->PHPShopConnectXML = new PHPShopConnectXML($this->data['domain'],$this->data['log'],$this->data['pas']);
    }

    function index() {

        if(PHPShopSecurity::true_num($GLOBALS['SysValue']['nav']['id'])) {
            $post = $this->PHPShopConnectXML->query('table_name2','select','id,name,price,pic_small,pic_big,content','id='.$GLOBALS['SysValue']['nav']['id'].' and enabled="1"');
            $xml = $this->PHPShopConnectXML->send($post);
            $db = $this->PHPShopConnectXML->readxml($xml);

            foreach($db as $k=>$row) {
                $this->set('productName',$row['name']);
                $this->set('productId',$row['id']);
                $this->set('productImg','http://'.$this->data['domain'].$row['pic_big']);
                $this->set('productPrice',$row['price']);
                $this->set('productContent',$row['content']);
                $dis=ParseTemplateReturn($GLOBALS['SysValue']['templates']['catalog']['product_forma_full'],true);
            }


            // ����
            $this->title=$row['name'].' - '.$this->PHPShopSystem->getValue("name");

            // ���������� ���������
            $this->set('pageContent',$dis);
            $this->set('pageTitle',$row['name']);
        }

        // ���������� ������
        $this->parseTemplate($this->getValue('templates.page_page_list'));

    }

}
?>