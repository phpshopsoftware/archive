// ��������������� �������
var TABLE_EVENT = true;
var ajax_path = "./order/ajax/";

$().ready(function() {

    // �������� ���� ������ - 2 ���
    $("body").on('click', "#selectModal .modal-footer .file-add-send", function(event) {
        event.preventDefault();
        var id = parseInt($('input[name=fileCount]').val());
        $('.file-list').append('<tr class="data-row" data-row="' + id + '"><td class="file-edit"><a href="' + $('input[name=lfile]').val() + '" class="file-edit"></a></td><td><input class="hidden-edit " value="" name="files_new[' + id + '][path]" type="hidden"><input class="hidden-edit" value="" name="files_new[' + id + '][name]" type="hidden"></td><td style="text-align:right" class="file-edit-path"><a href="' + $('input[name=lfile]').val() + '" class="file-edit-path" target="_blank"></a></td></tr>');
        $('.file-list [data-row="' + id + '"] .file-edit > a').html($('input[name=modal_file_name]').val());
        $('.file-list [data-row="' + id + '"] input[name="files_new[' + id + '][name]"]').val($('input[name=modal_file_name]').val());
        $('.file-list [data-row="' + id + '"] .file-edit-path > a').html('<span class="glyphicon glyphicon-floppy-disk"></span>' + $('input[name=lfile]').val());
        $('.file-list [data-row="' + id + '"] input[name="files_new[' + id + '][path]"]').val($('input[name=lfile]').val());
        $('.file-add').attr('data-count', id);
        $('#selectModal .modal-footer .btn-primary').removeClass('file-add-send');
        $('#selectModal').modal('hide');
    });

    // �������� ���� ������ - 1 ���
    $(".file-add").on('click', function(event) {
        event.preventDefault();

        var data = [];
        var id = $(this).closest('.data-row').attr('data-row');
        data.push({name: 'selectID', value: id});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'fileCount', value: $(this).attr('data-count')});
        data.push({name: 'actionList[selectID]', value: 'actionFileEdit'});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=product&id=file' + '&name=' + escape('����'),
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                $('#selectModal .modal-dialog').removeClass('modal-lg');
                $('#selectModal .modal-title').html(locale.file_add);
                $('#selectModal .modal-footer .btn-primary').removeClass('edit-select-send');
                $('#selectModal .modal-footer .btn-primary').addClass('file-add-send');
                $('#selectModal .modal-footer .btn-delete').addClass('hidden');
                $('#selectModal .modal-footer .btn-delete').addClass('file-delete');
                $('#selectModal .modal-body').html(data);

                $('.elfinder-modal-content').attr('data-option', 'return=lfile');
                $('#selectModal').modal('show');
            }
        });
    });

    // �������� ����� ������
    $("body").on('click', "#selectModal .modal-footer .file-delete", function(event) {
        event.preventDefault();
        var id = $('input[name=selectID]').val();
        if (confirm(locale.confirm_delete)) {
            $('.file-list [data-row="' + id + '"]').remove();
            $('#selectModal').modal('hide');
        }
    });

    // ������������� ���� ������ - 2 ���
    $("body").on('click', "#selectModal .modal-footer .file-edit-send", function(event) {
        event.preventDefault();
        var id = $('input[name=selectID]').val();

        var name = $('input[name=modal_file_name]').val();
        $('.file-list [data-row="' + id + '"] .file-edit > a').html(name);
        $('.file-list [data-row="' + id + '"] input[name="files_new[' + id + '][name]"]').val(name);
        $('.file-list [data-row="' + id + '"] .file-edit-path > a').html('<span class="glyphicon glyphicon-floppy-disk"></span>' + $('input[name=lfile]').val());
        $('.file-list [data-row="' + id + '"] input[name="files_new[' + id + '][path]"]').val($('input[name=lfile]').val());
        $('#selectModal').modal('hide');

    });

    // ������������� ���� ������
    $("body").on('click', ".data-row .file-edit > a", function(event) {
        event.preventDefault();

        var data = [];
        var id = $(this).closest('.data-row').attr('data-row');
        data.push({name: 'selectID', value: id});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'actionList[selectID]', value: 'actionFileEdit'});
        var name = $(this).html();

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=product&id=file&file=' + $(this).attr('href') + '&name=' + escape(name),
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                $('#selectModal .modal-dialog').removeClass('modal-lg');
                $('#selectModal .modal-title').html(locale.file_edit + ': ' + name);
                $('#selectModal .modal-footer .btn-primary').removeClass('edit-select-send');
                $('#selectModal .modal-footer .btn-primary').addClass('file-edit-send');
                $('#selectModal .modal-footer .btn-delete').removeClass('hidden');
                $('#selectModal .modal-footer .btn-delete').addClass('file-delete');
                $('#selectModal .modal-body').html(data);

                $('.elfinder-modal-content').attr('data-option', 'return=lfile');
                $('#selectModal').modal('show');
            }
        });
    });

    // ��������� ����� - 2 ���
    $("body").on('click', "#selectModal .modal-footer .option-send", function(event) {
        event.preventDefault();

        if ($('#selectModal input:checkbox:checked').length) {
            var data = [];
            $('#selectModal input:checkbox:checked').each(function() {
                data.push({name: 'option[' + $(this).attr('name') + ']', value: $(this).val()});

            });

            data.push({name: 'selectID', value: 1});
            data.push({name: 'ajax', value: 1});
            data.push({name: 'actionList[selectID]', value: 'actionOptionSave'});
            $.ajax({
                mimeType: 'text/html; charset=windows-1251',
                url: '?path=order.select',
                type: 'post',
                data: data,
                dataType: "json",
                async: false,
                success: function() {
                    window.location.reload();
                }

            });
        }
        else
            alert(locale.select_no);
    });

    // ��������� ����� - 1 ���
    $(".option").on('click', function(event) {
        event.preventDefault();

        var data = [];
        data.push({name: 'selectID', value: 1});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'actionList[selectID]', value: 'actionOption'});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=order.select',
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                $('#selectModal .modal-dialog').removeClass('modal-lg');
                $('#selectModal .modal-title').html(locale.option_title);
                $('#selectModal .modal-footer .btn-primary').addClass('option-send');
                $('#selectModal .modal-footer .btn-delete').addClass('hidden');
                $('#selectModal .modal-body').html(data);
                $('#selectModal').modal('show');
            }
        });
    });

    // ����� ������ � �������
    $('body').on('click', ".media-heading > a", function(event) {
        if ($('.bar-tab').is(":visible")) {
            event.preventDefault();
            $(this).closest(".data-row").find(".cart-value-edit").click();

        }
    });

    // ������������� � ���������� - 2 ���
    $("body").on('click', "#selectModal .modal-footer .edit-select-send", function(event) {
        event.preventDefault();

        if ($('#selectModal input:checkbox:checked').length) {
            var data = [];
            $('#selectModal input:checkbox:checked').each(function() {
                data.push({name: 'select_col[' + $(this).attr('name') + ']', value: $(this).attr('name')});

            });

            data.push({name: 'selectID', value: 1});
            data.push({name: 'ajax', value: 1});
            data.push({name: 'actionList[selectID]', value: 'actionSelectEdit'});
            $.ajax({
                mimeType: 'text/html; charset=windows-1251',
                url: '?path=order.select',
                type: 'post',
                data: data,
                dataType: "json",
                async: false,
                success: function() {
                    window.location.href = '?path=order.select';
                }

            });
        }
        else
            alert(locale.select_no);
    });

    // C���� ��������� ���������
    $('#selectModal').on('click', "#select-none", function(event) {
        event.preventDefault();
        $('#selectModal input:checkbox:checked').each(function() {
            this.checked = false;
        });
    });

    // �������� ��� ��������
    $('#selectModal').on('click', "#select-all", function(event) {
        event.preventDefault();
        $('#selectModal input:checkbox').each(function() {
            this.checked = true;
        });
    });

    // ������������� � ���������� - 1 ���
    $(".select-action .edit-select").on('click', function(event) {
        event.preventDefault();

        if ($('#data input:checkbox:checked').length) {
            var data = [];
            $('#data input:checkbox:checked').each(function() {
                if (this.value != 'all')
                    data.push({name: 'select[' + $(this).attr('data-id') + ']', value: $(this).attr('data-id')});

            });

            data.push({name: 'selectID', value: 1});
            data.push({name: 'ajax', value: 1});
            data.push({name: 'actionList[selectID]', value: 'actionSelect'});

            $.ajax({
                mimeType: 'text/html; charset=windows-1251',
                url: '?path=order.select',
                type: 'post',
                data: data,
                dataType: "html",
                async: false,
                success: function(data) {
                    $('#selectModal .modal-title').html(locale.select_title);
                    $('#selectModal .modal-footer .btn-primary').html(locale.select_edit);
                    $('#selectModal .modal-footer .btn-primary').addClass('edit-select-send');
                    $('#selectModal .modal-body').html(data);
                    $('#selectModal').modal('show');
                }
            });
        }
        else
            alert(locale.select_no);
    });


    // datetimepicker
    if ($(".date").length) {
        $(".date").datetimepicker({
            format: 'dd-mm-yyyy',
            language: 'ru',
            weekStart: 1,
            todayBtn: 1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 2,
            minView: 2,
            forceParse: 0
        });
    }

    // ����� ������ - �������
    $(".btn-order-cancel").on('click', function() {
        table.api().ajax.url(ajax_path + 'order.ajax.php').load();
        $(this).addClass('hide');
    });

    // ����� ������
    $(".btn-order-search").on('click', function() {
        var push = '?';
        $('#order_search .form-control, #order_search .selectpicker').each(function() {
            if ($(this).attr('name') !== undefined) {
                push += $(this).attr('name') + '=' + escape($(this).val()) + '&';
            }
        });
        table.api().ajax.url(ajax_path + 'order.ajax.php' + push).load();
        $('.btn-order-cancel').removeClass('hide');
    });

    // ������� ����� �� ������ �������
    $("body").on('click', ".dropdown-menu .copy", function() {
        $(this).attr('href', '?path=order&action=new&id=' + $(this).attr('data-id'));
    });

    // ����� e-mail �� ������ �������
    $("body").on('click', ".dropdown-menu .email", function() {
        $(this).attr('href', 'mailto:' + $('#order-' + $(this).attr('data-id') + '-email').html());
    });

    // �������� ������
    $(".btn-print-order").on('click', function() {
        window.open($(this).attr('data-option'));
    });

    // �������� ������ ������
    $(".discount").on('click', function() {

        var order_id = $('#footer input[name=rowID]').val();
        var data = [];
        data.push({name: 'selectID', value: $('.discount-value').val()});
        data.push({name: 'selectAction', value: 'discount'});
        data.push({name: 'actionList[selectID]', value: 'actionCartUpdate.order.edit'});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=order&id=' + order_id,
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function() {
                window.location.reload();
            }

        });
    });

    // �������� � ������� - �����
    $("body").on('click', "#selectModal .search-action", function(event) {
        event.preventDefault();

        var data = [];
        data.push({name: 'selectID', value: 1});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'actionList[selectID]', value: 'actionSearch'});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=catalog.search&words=' + escape($('input:text[name=search_name]').val()) + '&cat=' + $('select[name=search_category]').val() + '&price_start=' + $('input:text[name=search_price_start]').val() + '&price_end=' + $('input:text[name=search_price_end]').val(),
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                $('#selectModal .modal-body').html(data);
            }

        });
    });

    // �������� � ������� ����� -  2 ���
    $("body").on('click', "#selectModal .modal-footer .cart-add-send", function(event) {
        event.preventDefault();
        var count = 0;
        var order_id = $('#footer input[name=rowID]').val();

        // Progress 
        $('#selectModal .modal-footer .btn').addClass('hidden');
        $('.progress').removeClass('hidden');

        // ����� ���������
        $('.cart-list input:text').each(function() {
            if (this.value > 0 || $(this).attr('data-cart') == "true")
                count++;
        });
        var total = $('.progress').width() / count;

        $('.cart-list input:text').each(function() {
            if (this.value > 0 || $(this).attr('data-cart') == "true") {
                var data = [];
                data.push({name: 'selectID', value: $(this).attr('data-id')});
                data.push({name: 'selectNum', value: this.value});
                data.push({name: 'ajax', value: 1});
                data.push({name: 'selectAction', value: 'add'});
                data.push({name: 'actionList[selectID]', value: 'actionCartUpdate.order.edit'});

                $.ajax({
                    mimeType: 'text/html; charset=windows-1251',
                    url: '?path=order&id=' + order_id,
                    type: 'post',
                    data: data,
                    dataType: "html",
                    async: false,
                    success: function() {

                        // Progress 
                        var progress = parseInt($('.progress-bar').css('width').split('px').join(''));
                        $('.progress-bar').css('width', (progress + total) + 'px');

                    }
                });
            }
        });

        $('#selectModal').modal('show');
        $('.progress-bar').css('width', '100%');
        window.location.reload();
    });

    // ���������� ����� ������� � ������ ������
    $("body").on('click', ".item-minus", function() {
        var id = $(this).attr('data-id');
        var current = $('#select_id_' + id).val();
        current--;
        if (current < 0)
            current = 0;
        else if (isNaN(current))
            current = 0;
        $('#select_id_' + id).val(parseInt(current));
    });

    $("body").on('click', ".item-plus", function() {
        var id = $(this).attr('data-id');
        var current = $('#select_id_' + id).val();
        current++;
        if (isNaN(current))
            current = 1;
        $('#select_id_' + id).val(parseInt(current));
    });


    // �������� � ������� ����� - 1 ���
    $(".cart-add").on('click', function(event) {
        event.preventDefault();

        var data = [];
        data.push({name: 'selectID', value: 1});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'actionList[selectID]', value: 'actionSearch'});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=catalog.search',
            type: 'post',
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                //$('#selectModal .modal-dialog').removeClass('modal-lg');
                $('#selectModal .modal-title').html(locale.add_cart_value);
                $('#selectModal .modal-footer .btn-primary').removeClass('edit-select-send');
                $('#selectModal .modal-footer .btn-primary').addClass('cart-add-send');
                $('#selectModal .modal-footer .btn-delete').addClass('hidden');
                $('#selectModal .modal-body').css('max-height', ($(window).height() - 200) + 'px');
                $('#selectModal .modal-body').css('overflow-y', 'auto');
                $('#selectModal .modal-body').html(data);
                $('#selectModal').modal('show');
            }
        });
    });

    // �������� �� ������ ������ ������ �������
    $(".data-row .cart-value-remove").on('click', function(event) {
        event.preventDefault();

        var order_id = $('#footer input[name=rowID]').val();
        var product_id = $(this).attr('data-id');

        if (confirm(locale.confirm_delete)) {

            var data = [];
            data.push({name: 'selectID', value: product_id});
            data.push({name: 'selectAction', value: 'delete'});
            data.push({name: 'actionList[selectID]', value: 'actionCartUpdate.order.edit'});

            $('#modal-form').attr('action', '?path=order&id=' + order_id);
            $('#modal-form').ajaxSubmit({
                data: data,
                dataType: "json",
                success: function(json) {
                    $('#selectModal').modal('hide');
                    window.location.reload();
                }
            });
        }
    });

    // �������� ������ �� ������ ��������� ����
    $("body").on('click', "#selectModal .modal-footer .value-delete", function(event) {
        event.preventDefault();

        var product_id = $('.modal-body input[name=rowID]').val();
        var order_id = $('.modal-body input[name=orderID]').val();

        if (confirm(locale.confirm_delete)) {

            var data = [];
            data.push({name: 'selectID', value: product_id});
            data.push({name: 'selectAction', value: 'delete'});
            data.push({name: 'actionList[selectID]', value: 'actionCartUpdate.order.edit'});

            $('#modal-form').attr('action', '?path=order&id=' + order_id);
            $('#modal-form').ajaxSubmit({
                data: data,
                dataType: "json",
                success: function(json) {
                    $('#selectModal').modal('hide');
                    window.location.reload();
                }
            });
        }
    });

    // ������������� ������� - 2 ���
    $("body").on('click', "#selectModal .modal-footer .value-edit-send", function(event) {
        event.preventDefault();

        var product_id = $('#modal-form input[name=rowID]').val();
        var order_id = $('#modal-form input[name=orderID]').val();

        var data = [];
        data.push({name: 'selectID', value: product_id});
        data.push({name: 'actionList[selectID]', value: 'actionCartUpdate.order.edit'});
        $('#modal-form .form-control, #modal-form .hidden-edit, #modal-form input:radio:checked, #modal-form input:checkbox:checked').each(function() {
            if ($(this).attr('name') !== undefined) {
                data.push({name: $(this).attr('name'), value: escape($(this).val())});
            }
        });

        $('#modal-form').attr('action', '?path=order&id=' + order_id);
        $('#modal-form').ajaxSubmit({
            data: data,
            dataType: "json",
            success: function(json) {
                $('#selectModal').modal('hide');
                if (json['success'] == 1) {
                    window.location.reload();
                } else
                    showAlertMessage(locale.save_false, true);
            }

        });

    });

    // ������������� ������� - 1 ���
    $("body").on('click', ".data-row .cart-value-edit", function(event) {
        event.preventDefault();

        var data = [];
        var id = $(this).attr('data-id');
        var order_id = $('#footer input[name=rowID]').val();
        var parent = $(this).closest('.data-row').attr('data-row');
        data.push({name: 'selectID', value: escape(id)});
        data.push({name: 'ajax', value: 1});
        data.push({name: 'actionList[selectID]', value: 'actionValueEdit'});
        data.push({name: 'parentID', value: parent});

        $.ajax({
            mimeType: 'text/html; charset=windows-1251',
            url: '?path=order&id=' + order_id,
            data: data,
            dataType: "html",
            async: false,
            success: function(data) {
                $('#selectModal .modal-dialog').removeClass('modal-lg');
                $('#selectModal .modal-title').html(locale.edit_cart_value);
                $('#selectModal .modal-footer .btn-primary').removeClass('edit-select-send');
                $('#selectModal .modal-footer .btn-primary').addClass('value-edit-send');
                $('#selectModal .modal-footer .btn-delete').removeClass('hidden');
                $('#selectModal .modal-footer .btn-delete').addClass('value-delete');
                $('#selectModal .modal-body').html(data);
                $('#selectModal').modal('show');
            }

        });
    });

    // �������������� � ����������
    $(".select-action .export-select").on('click', function(event) {
        event.preventDefault();

        if ($('input:checkbox:checked').length) {
            var data = [];
            $('input:checkbox:checked').each(function() {
                if (this.value != 'all')
                    data.push({name: 'select[' + $(this).attr('data-id') + ']', value: $(this).attr('data-id')});
            });

            data.push({name: 'selectID', value: 1});
            data.push({name: 'ajax', value: 1});
            data.push({name: 'actionList[selectID]', value: 'actionSelect'});
            $.ajax({
                mimeType: 'text/html; charset=windows-1251',
                url: '?path=exchange.export.order',
                type: 'post',
                data: data,
                dataType: "json",
                async: false,
                success: function() {
                    window.location.href = '?path=exchange.export.order';
                }

            });
        }
        else
            alert(locale.select_no);
    });

    // ��������� bootstrap-select
    $('.selectpicker').selectpicker({
        dropdownAlignRight: true
    });

    // ���������� ������
    $("button[name=editID]").on('click', function() {
        $('#user-data-1 .sidebar-data-0').text($('#product_edit input[name=fio_new]').val());
        $('#user-data-1 .sidebar-data-2').text($('#product_edit input[name=tel_new]').val());
        $('#user-data-2 .sidebar-data-0').text($('#product_edit input[name=fio_new]').val());
        $('#user-data-2 .sidebar-data-1').text($('#product_edit input[name=tel_new]').val());
    });

    // �����
    if ($('#map').length) {
        ymaps.ready(init);
    }
    function init() {
        ymaps.geocode($('#map').attr('data-geocode'), {results: 1}).then(function(res) {
            var firstGeoObject = res.geoObjects.get(0);
            //res.geoObjects.get(0).properties.set('balloonContentHeader', '��������');
            res.geoObjects.get(0).properties.set('balloonContentBody', $('#map').attr('data-title'));
            window.myMap = new ymaps.Map("map", {
                center: firstGeoObject.geometry.getCoordinates(),
                zoom: 10
            });
            myMap.controls.add('mapTools', {left: 5, top: 5});
            firstGeoObject.options.set('preset', 'twirl#buildingsIcon');
            myMap.geoObjects.add(firstGeoObject);
        });
    }

    // ��������� �� ������ dropdown
    $("body").on('mouseenter', '.data-row', function() {
        $(this).find('#dropdown_action').show();
    });
    $("body").on('mouseleave', '.data-row', function() {
        $(this).find('#dropdown_action').hide();
    });


    // ������� ������
    if (typeof($.cookie('data_length')) == 'undefined')
        var data_length = [10, 25, 50, 75, 100, 500];
    else
        var data_length = [parseInt($.cookie('data_length')), 10, 25, 50, 75, 100, 500];

    if ($('#data').html()) {
        var table = $('#data').dataTable({
            "ajax": {
                "type": "GET",
                "url": ajax_path + 'order.ajax.php' + window.location.search,
                "dataSrc": function(json) {
                    $('#stat_sum').text(json.sum);
                    $('#stat_num').text(json.num);
                    return json.data;
                }
            },
            "processing": true,
            "serverSide": true,
            "paging": true,
            "ordering": true,
            "order": [[3, "desc"]],
            "info": false,
            "searching": true,
            "lengthMenu": data_length,
            "language": locale.dataTable,
            "stripeClasses": ['data-row', 'data-row'],
            "aoColumnDefs": [{
                    'bSortable': false,
                    'aTargets': ['sorting-hide']
                }]
        });
    }

});