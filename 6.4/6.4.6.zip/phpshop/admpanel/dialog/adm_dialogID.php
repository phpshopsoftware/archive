<?php

$TitlePage = __('������') . ' #' . $_GET['id'];
$PHPShopOrm = new PHPShopOrm($GLOBALS['SysValue']['base']['dialog']);
PHPShopObj::loadClass('bot');

function actionStart() {
    global $PHPShopGUI, $PHPShopOrm, $chat_name, $PHPShopSystem;

    // ����� ������
    if (isset($_GET['new'])) {
        $user = intval($_GET['user']);
        $bot = new PHPShopBot();
        $insert = array(
            'user_id' => $user,
            'chat' => array
                (
                'id' => $user,
                'first_name' => "�������������",
                'last_name' => "",
            ),
            'date' => time(),
            'text' => '',
            'staffid' => 0,
            'attachments' => null,
            'bot' => 'message',
            'isview' => 1,
            'isview_user' => 0
        );

        if (!empty($user))
            $bot->dialog($insert);
    }

    $PHPShopGUI->addCSSFiles('./css/support.css');
    $PHPShopGUI->addJSFiles('./js/jquery.waypoints.min.js', './dialog/gui/dialog.gui.js');
    $PHPShopOrm->debug = false;
    $data = $PHPShopOrm->select(array('*'), array('chat_id' => "=" . intval($_GET['id']), 'bot' => '="' . PHPShopSecurity::TotalClean($_GET['bot']) . '"', 'user_id' => '=' . intval($_GET['user'])), array('order' => 'id'), array('limit' => 500));

    // ��� ������
    if (!is_array($data)) {
        header('Location: ?path=' . $_GET['path']);
        exit();
    }

    $PHPShopGUI->action_button['������'] = array(
        'name' => '������',
        'class' => 'btn btn-default btn-sm navbar-btn up hide',
        'type' => 'button',
        'icon' => 'glyphicon glyphicon-arrow-up',
    );

    $PHPShopGUI->action_select['������ ������������'] = array(
        'name' => '������ ������������',
        'url' => '?path=order&where[a.user]=' . intval($_GET['user']),
    );

    $PHPShopGUI->action_select['������������'] = array(
        'name' => '������������',
        'url' => '?path=shopusers&id=' . intval($_GET['user']) . '&return=dialog',
    );


    if (is_array($data)) {

        // ���������
        $message = viewMessage($data);
    }

    // ������
    $answer_list = null;
    $PHPShopOrmAnswer = new PHPShopOrm($GLOBALS['SysValue']['base']['dialog_answer']);
    $data_answer = $PHPShopOrmAnswer->select(array('*'), array('enabled' => "='1'"), array('order' => 'num'), array('limit' => 15));
    if (is_array($data_answer))
        foreach ($data_answer as $row)
            $answer_list .= '<li><a href="#" class="dialog-answer" data-content="' . str_replace('"', "", $row['message']) . '">' . $row['name'] . '</a></li>';

    if (!empty($answer_list))
        $answer_list .= '<li role="separator" class="divider"></li>';
    $answer = '<ul class="dropdown-menu">' . $answer_list . ' <li><a href="?path=dialog.answer&return=dialog&action=new"><span class="glyphicon glyphicon-plus"></span> ' . __('�������� �����') . '</a></li></ul>';

    $PHPShopGUI->setActionPanel(__("������") . " " . $chat_name, array('������������', '������ ������������', '|', '�������'), array('������ ������������', '������'));

    // �������� �� ���
    $PHPShopOrmUser = new PHPShopOrm($GLOBALS['SysValue']['base']['shopusers']);
    $data_user = $PHPShopOrmUser->getOne(array('*'), array('id' => "=" . intval($_GET['user'])));

    if (!empty($data_user['dialog_ban']))
        $PHPShopGUI->_CODE = $PHPShopGUI->setAlert('������ ������������', $type = 'danger');
    else
        $PHPShopGUI->_CODE = '

          <div id="message-list">' . $message . '</div>
          <div id="message-preloader"><img src="images/ajax-loader.gif" title="��������"></div>
          <div class="text-muted pull-right">' . __('����������� [Shift] ��� �������� ������') . '</div>
          <form method="post" enctype="multipart/form-data" id="product_edit" class="form-horizontal" role="form" data-toggle="validator">
          <a id="m"></a>
          <div>
          <p>
          <textarea class="form-control" name="message" id="message" placeholder="' . __('������� �����') . '"></textarea>
          </p>
          
          <div class="row">
            <div class="col-md-6 col-xs-6">
            <a id="attachment-disp" class="text-muted" href="#f"><span class="glyphicon glyphicon-paperclip"></span> ' . __('���������� ����') . '</a>
             <a id="f"></a>
             <div id="attachment" class="hide" style="max-width:70%">
             ' . $PHPShopGUI->setIcon(null, "attachment", false, array('load' => true, 'server' => true, 'url' => false, 'multi' => false, 'view' => false)) . '
             </div>
            </div>
            <div class="col-md-6 col-xs-6 text-right">

             <div class="btn-group dropup">
             <button class="btn btn-default send-message disabled" type="button"><span class="glyphicon glyphicon-send"></span> ' . __('���������') . '</button>
              <button type="button" class="btn btn-default dropdown-toggle " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="caret"></span> <span class="sr-only">Toggle Dropdown</span> </button>
              ' . $answer . '
             
           </div>

           </div>
          </div>

          <br>
          </div>
          <input type="hidden" name="selectID" value="true">
          <input type="hidden" name="actionList[delID]" value="actionDelete.shopusers.edit">
          <input type="hidden" name="actionList[selectID]" value="actionReplies.shopusers.edit">
          <input type="hidden" name="chat_id" value="' . $_GET['id'] . '">
          <input type="hidden" name="user_id" value="' . intval($_GET['user']) . '">
          <input type="hidden" name="bot" value="' . $_GET['bot'] . '">
         </form>
      ';

    if (empty($_GET['search'])) {
        $class = 'none';
        $_GET['search'] = null;
    } else
        $class = null;

    // ����� ��������
    $search = '<div class="' . $class . '" id="dialog-search" style="padding-bottom:5px;"><div class="input-group input-sm">
                <input type="input" class="form-control input-sm" type="search" id="input-dialog-search" placeholder="' . __('������ � ��������...') . '" value="' . PHPShopSecurity::TotalClean($_GET['search']) . '">
                 <span class="input-group-btn">
                  <a class="btn btn-default btn-sm" id="btn-search" type="submit"><span class="glyphicon glyphicon-search"></span></a>
                 </span>
            </div></div>';

    $sidebarleft[] = array('title' => '������������', 'content' => $search . $PHPShopGUI->loadLib('tab_dialog', false, './dialog/'), 'title-icon' => '<div class="hidden-xs"><span class="glyphicon glyphicon-search" id="show-dialog-search" data-toggle="tooltip" data-placement="top" title="' . __('�����') . '"></span></div>');
    // ����������
    $sidebarright[] = array('id' => 'user-data-1', 'title' => '������������', 'name' => array('caption' => $data_user['name'], 'link' => '?path=shopusers&return=order.' . $data_user['id'] . '&id=' . $data_user['id'] . '&return=dialog'), 'content' => array(array('caption' => $data_user['login'], 'link' => 'mailto:' . $data_user['login']), $data_user['tel']));

    // ������
    $tab_order = $PHPShopGUI->loadLib('tab_order', false, './dialog/');
    if (!empty($tab_order))
        $sidebarright[] = array('title' => '������', 'content' => $tab_order);

    // �������
    $tab_cart = $PHPShopGUI->loadLib('tab_cart', false, './dialog/');
    if (!empty($tab_cart))
        $sidebarright[] = array('title' => '�������', 'content' => $tab_cart);

    // ������.�����
    $yandex_apikey = $PHPShopSystem->getSerilizeParam("admoption.yandex_apikey");
    if (empty($yandex_apikey))
        $yandex_apikey = 'cb432a8b-21b9-4444-a0c4-3475b674a958';

    // �����
    $mass = unserialize($data_user['data_adres']);
    if (strlen($mass['list'][$mass['main']]['street_new']) > 5) {
        $PHPShopGUI->addJSFiles('./shopusers/gui/shopusers.gui.js', '//api-maps.yandex.ru/2.0/?load=package.standard&lang=ru-RU&apikey=' . $yandex_apikey);
        $map = '<div id="map" data-geocode="' . $mass['list'][$mass['main']]['city_new'] . ', ' . $mass['list'][$mass['main']]['street_new'] . ' ' . $mass['list'][$mass['main']]['house_new'] . '"></div>';

        $sidebarright[] = array('title' => '����� �������� �� �����', 'content' => array($map));
    }

    $PHPShopGUI->setSidebarLeft($sidebarleft, 3);
    $PHPShopGUI->sidebarLeftCell = 3;
    $PHPShopGUI->setSidebarRight($sidebarright, 2, 'hidden-xs');
    $PHPShopGUI->Compile(false);
}

// ������� ������ 
function actionReplies() {
    global $PHPShopSystem;

    switch ($_GET['bot']) {
        case "telegram":
            $bot = new PHPShopTelegramBot();
            break;
        case "vk":
            $bot = new PHPShopVKBot();
            break;
        default: $bot = new PHPShopBot();
    }

    if (!empty($_POST['attachment'])) {

        $fileAdd = fileAdd();
        if (!empty($fileAdd))
            $_POST['attachment'] = $fileAdd;

        $file = $bot->protocol . $_SERVER['SERVER_NAME'] . $_POST['attachment'];

        // ��������
        if (in_array(PHPShopSecurity::getExt($_POST['attachment']), array('gif', 'png', 'jpg', 'jpeg'))) {

            if (empty($_POST['message']))
                $_POST['message'] = PHPShopString::win_utf8("��������");

            $bot->send_image($_POST['chat_id'], $_POST['message'], $_POST['attachment']);
        }
        // ��������
        else {

            if (empty($_POST['message']))
                $_POST['message'] = PHPShopString::win_utf8("����");

            $bot->send_file($_POST['chat_id'], $_POST['message'], $_POST['attachment']);
        }
    }
    // �����
    else
        $bot->send($_POST['chat_id'], $_POST['message']);


    $insert = array(
        'user_id' => $_POST['user_id'],
        'chat' => array
            (
            'id' => $_POST['chat_id'],
            'first_name' => $_SESSION['namePHPSHOP'],
            'last_name' => "",
        ),
        'date' => time(),
        'text' => $_POST['message'],
        'staffid' => 0,
        'attachments' => $file,
        'bot' => $_GET['bot'],
        'isview' => 0,
        'isview_user' => 0
    );

    $bot->dialog($insert);

    if (!empty($_POST['message']) and $_GET['bot'] == 'message') {
        PHPShopObj::loadClass("user");
        $PHPShopUser = new PHPShopUser($_POST['user_id']);
        $title = __('����� ����� � �������') . ' - ' . $PHPShopSystem->getName();
        $PHPShopMail = new PHPShopMail($PHPShopUser->getLogin(), $PHPShopSystem->getEmail(), $title, '', true, true);
        $text = PHPShopString::utf8_win1251('<b>' . __('�������������') . '</b>: ' . $_POST['message']) . ' ' . preg_replace("~(http|https|ftp|ftps)://(.*?)(\s|\n|[,.?!](\s|\n)|$)~", '<a href="$1://$2" target="_blank">$1://$2</a>$3', $file) . '<div><br>' . __('�� ������ �������� ��� �') . ' <a href="' . $bot->protocol . $_SERVER['SERVER_NAME'] . $GLOBALS['SysValue']['dir']['dir'] . '/users/message.html" target="_blank">' . __('������ ��������') . '</a></div> ';
        PHPShopParser::set('content', $text);
        $content = PHPShopParser::file('tpl/sendmail.mail.tpl', true, false);
        $PHPShopMail->sendMailNow($content);
    }

    header("Content-Type: application/json");
    exit(json_encode(array('success' => 1)));
}

// ���������� �����
function fileAdd() {
    global $PHPShopSystem;

    // ����� ����������
    $path = $GLOBALS['SysValue']['dir']['dir'] . '/UserFiles/Image/' . $PHPShopSystem->getSerilizeParam('admoption.image_dialog_path');

    // �������� �� ������������
    if (!empty($_FILES['file']['name'])) {
        $_FILES['file']['ext'] = PHPShopSecurity::getExt($_FILES['file']['name']);
        $_FILES['file']['name'] = PHPShopString::toLatin(str_replace('.' . $_FILES['file']['ext'], '', PHPShopString::utf8_win1251($_FILES['file']['name']))) . '.' . $_FILES['file']['ext'];
        if (!empty($_FILES['file']['ext'])) {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $GLOBALS['dir']['dir'] . $path . $_FILES['file']['name'])) {
                $file = $GLOBALS['dir']['dir'] . $path . $_FILES['file']['name'];
            }
        } else
            $file = 'Error_PHP_ext';
    }

    if (empty($file))
        $file = '';

    return $file;
}

/**
 * ������ ���������
 */
function viewMessage($data, $ajax = false) {
    global $chat_ids, $chat_name;

    $message = null;
    if (is_array($data)) {
        foreach ($data as $row) {

            if (empty($row['message']) and empty($row['attachments']))
                continue;

            if (empty($row['isview']) and empty($ajax))
                continue;

            $chat_ids[] = $row['id'];

            // ������
            $row['message'] = preg_replace("~(http|https|ftp|ftps)://(.*?)(\s|\n|[,.?!](\s|\n)|$)~", '<a href="$1://$2" target="_blank">$1://$2</a>$3', $row['message']);

            // �����
            if (!empty($row['attachments'])) {

                $url = parse_url($row['attachments']);

                if (in_array(PHPShopSecurity::getExt($url['path']), array('gif', 'png', 'jpg', 'jpeg'))) {
                    $flist = '<div class="col-xs-6 col-md-6">
                             <a href="' . $row['attachments'] . '" class="thumbnail" target="_blank" title="' . $row['attachments'] . '"><img src="' . $row['attachments'] . '" alt="" ></a></div>';
                } else {
                    $path = pathinfo($row['attachments']);
                    $path = parse_url($path['basename']);

                    $flist = '<div class="col-xs-12 col-md-12"><a title="" target="_blank" href="' . $row['attachments'] . '"><span class="glyphicon glyphicon-paperclip"></span> ' . $path['path'] . '</a></div>';
                }
            } else
                $flist = null;

            if (empty($row['staffid'])) {

                $message .= '
             <div class="incoming_msg">
              <div class="received_msg">
                <div class="received_withd_msg">
                   <span class="time_date">' . PHPShopDate::get($row['time'], true) . '</span>
                    <p>' . nl2br($row['message']) . '</p>
                    <span class="time_date"><div class="row">' . $flist . '</div></span>
                 </div>
              </div>
            </div>';
            } else {
                $chat_name = '<a href="?path=shopusers&id=' . $row['user_id'] . '&return=dialog"><img src="../lib/templates/messenger/' . $row['bot'] . '.svg" title="' . ucfirst($row['bot']) . '" class="bot-icon">' . $row['name'] . '</a>';
                $message .= '
            <div class="outgoing_msg">
              <div class="sent_msg">
                <span class="time_date text-right">' . $row['name'] . ': ' . PHPShopDate::get($row['time'], true) . '</span>
                <p>' . nl2br($row['message']) . '</p>
                <span class="time_date"><div class="row">' . $flist . '</div></span>
               </div>
            </div>';
            }
        }
    }
    return $message;
}

/**
 * ������� ����� ��������
 */
function actionGetNew() {
    global $PHPShopOrm;

    $PHPShopOrm->debug = false;
    $data = $PHPShopOrm->select(array('*'), array('chat_id' => "=" . intval($_GET['id']), 'isview' => "='0'", 'bot' => '="' . PHPShopSecurity::TotalClean($_GET['bot']) . '"'), array('order' => 'id'), array('limit' => 500));

    // ���������
    if (is_array($data)) {
        $message = viewMessage($data, true);
    }

    if (!empty($message) and is_array($GLOBALS['chat_ids'])) {
        $PHPShopOrm->update(array('isview_new' => 1), array('id' => ' IN (' . implode(',', $GLOBALS['chat_ids']) . ')'));
    }

    if (!empty($message)) {
        $count = count($data);
    } else {
        $count = 0;
        $message = null;
    }

    header("Content-Type: application/json");
    exit(json_encode(array('success' => 1, 'num' => intval($count), 'message' => PHPShopString::win_utf8($message))));
}

// ������� ��������
function actionDelete() {
    global $PHPShopOrm, $PHPShopModules;

    // �������� ������
    $PHPShopModules->setAdmHandler(__FILE__, __FUNCTION__, $_POST);

    $action = $PHPShopOrm->delete(array('chat_id' => '=' . $_POST['chat_id']));
    return array("success" => $action);
}

// ��������� �������
$PHPShopGUI->getAction();

// ����� ����� ��� ������
$PHPShopGUI->setAction($_GET['id'], 'actionStart', 'none');
?>