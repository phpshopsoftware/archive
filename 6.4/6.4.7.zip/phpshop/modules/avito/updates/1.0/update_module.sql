ALTER TABLE `phpshop_modules_avito_system` ADD `additional_description` text default null;
ALTER TABLE `phpshop_modules_avito_system` ADD `image_url` varchar(255) default '';