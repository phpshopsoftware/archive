ALTER TABLE  `phpshop_categories` ADD  `dop_cat` varchar(255) DEFAULT '';
ALTER TABLE  `phpshop_delivery` ADD  `payment` varchar(255) DEFAULT '';